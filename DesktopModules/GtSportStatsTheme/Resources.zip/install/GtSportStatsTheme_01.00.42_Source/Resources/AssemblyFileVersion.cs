﻿//1
//0
//0
//42
//
//
using System.Reflection;
[assembly: AssemblyVersion("1.0.0.42")]
[assembly: AssemblyFileVersion("1.0.0.42")]
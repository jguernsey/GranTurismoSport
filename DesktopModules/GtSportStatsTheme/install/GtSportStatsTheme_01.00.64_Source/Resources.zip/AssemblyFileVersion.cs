﻿//1
//0
//0
//64
//
//
using System.Reflection;
[assembly: AssemblyVersion("1.0.0.64")]
[assembly: AssemblyFileVersion("1.0.0.64")]
//1
//0
//0
//28
//
//
using System.Reflection;
[assembly: AssemblyVersion("1.0.0.28")]
[assembly: AssemblyFileVersion("1.0.0.28")]

//1
//0
//0
//50
//
//
using System.Reflection;
[assembly: AssemblyVersion("1.0.0.50")]
[assembly: AssemblyFileVersion("1.0.0.50")]
